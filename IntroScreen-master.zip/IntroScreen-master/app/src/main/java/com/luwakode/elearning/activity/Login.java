package com.luwakode.elearning.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.luwakode.aws.introscreen.R;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
